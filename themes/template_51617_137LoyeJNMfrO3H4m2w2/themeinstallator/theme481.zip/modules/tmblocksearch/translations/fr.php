<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmblocksearch}prestashop>tmblocksearch-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Rechercher';
$_MODULE['<{tmblocksearch}prestashop>tmblocksearch_31a0c03d7fbd1dc61d3b8e02760e703b'] = 'Bloc recherche rapide';
$_MODULE['<{tmblocksearch}prestashop>tmblocksearch_99e20473c0bf3c22d7420eff03ce66c3'] = 'Ajoute un bloc avec un champ de recherche rapide';
$_MODULE['<{tmblocksearch}prestashop>tmblocksearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Rechercher';
$_MODULE['<{tmblocksearch}prestashop>tmblocksearch_52d578d063d6101bbdae388ece037e60'] = 'Saisissez un nom de produit';
$_MODULE['<{tmblocksearch}prestashop>tmblocksearch_34d1f91fb2e514b8576fab1a75a89a6b'] = 'ok';
