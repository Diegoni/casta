<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-footer_e1da49db34b0bdfdddaba2ad6552f848'] = 'mapa del sitio';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-footer_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'contacto';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-footer_05eb51862bc90ef24d04f3f1d8be5274'] = 'añada esta página a favoritos';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-header_106a6c241b8797f52e1e77317b96a201'] = 'Inicio';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-header_51d9a87ceb513de9363d548dc1bee90d'] = 'Especiales';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-header_9ff0635f5737513b1a6f559ac2bff745'] = 'Novedades';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-header_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Su cuenta';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-header_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'contacto';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-header_e1da49db34b0bdfdddaba2ad6552f848'] = 'mapa del sitio';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks_39355c36cfd8f1d048a1f84803963534'] = 'Bloque de enlaces permanentes';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks_3a3bf29ed9ddeb6210a731d2b1454df2'] = 'Añadir un bloque que muestre los enlaces permanentes como mapa del sitio, contacto, etc.';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks_e1da49db34b0bdfdddaba2ad6552f848'] = 'mapa del sitio';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'contacto';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks_05eb51862bc90ef24d04f3f1d8be5274'] = 'añada esta página a favoritos';
