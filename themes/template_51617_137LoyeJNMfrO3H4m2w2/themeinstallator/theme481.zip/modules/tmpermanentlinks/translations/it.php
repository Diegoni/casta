<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-footer_e1da49db34b0bdfdddaba2ad6552f848'] = 'Mappa del sito';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-footer_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'contatto';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-footer_05eb51862bc90ef24d04f3f1d8be5274'] = 'Segna questa pagina';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-header_106a6c241b8797f52e1e77317b96a201'] = 'Home page';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-header_51d9a87ceb513de9363d548dc1bee90d'] = 'Speciali';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-header_9ff0635f5737513b1a6f559ac2bff745'] = 'Nuovi prodotti';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-header_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Benvenuti';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-header_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'Contatto';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks-header_e1da49db34b0bdfdddaba2ad6552f848'] = 'Mappa del sito';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks_39355c36cfd8f1d048a1f84803963534'] = 'Blocco link permanenti';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks_3a3bf29ed9ddeb6210a731d2b1454df2'] = 'Aggiunge un blocco che visualizza i link permanenti come mappa del sito, contatti, ecc';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks_e1da49db34b0bdfdddaba2ad6552f848'] = 'Mappa del sito';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'contatto';
$_MODULE['<{tmpermanentlinks}prestashop>tmpermanentlinks_05eb51862bc90ef24d04f3f1d8be5274'] = 'Segna questa pagina';
