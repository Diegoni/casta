<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_cd2c2dc24eaf11ba856da4a2e2a248be'] = 'Prodotti in vetrina sulla homepage';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_bedd0eb227b31705fce270fe1ec5639f'] = 'Mostra Prodotti in vetrina nel cuore della tua home page';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_dd0de17e8450a0fd3248b19c4a4f803b'] = 'Numero non valido di prodotti';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_6df1f9b5662398a551a2c9185b26638a'] = 'Per poter aggiungere prodotti alla tua home page, basta aggiungere alla categoria \"home\".';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_3c230497560c52be92b93c65de9defc9'] = 'Numero di prodotto esposto';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_5bc8290012fcc597689ef8959c2fc969'] = 'Il numero di prodotti esposti in homepage (default: 10)';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'prodotti in vetrina';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nuovo';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Più';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'Visualizza';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'Aggiungi al carrello';
$_MODULE['<{tmhomefeatured}prestashop>tmhomefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'Nessun prodotto in vetrina';
